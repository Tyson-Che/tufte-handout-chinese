# Tufte Handout Chinese

This is a modified version of the Tufte Handout class for Chinese documents.

## Installation

1. Copy tufte-handout-chinese.cls and tufte-common-modified.def to your LaTeX project directory or your local texmf tree.
2. Use \documentclass{tufte-handout-chinese} in your LaTeX document.

## Usage

See example.tex for a basic usage example.
